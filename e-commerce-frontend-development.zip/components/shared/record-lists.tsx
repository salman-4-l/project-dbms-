'use client'

import { Receipt, RotateCcw, Wallet } from 'lucide-react'
import { RecordsView } from '@/components/shared/records-view'
import { useOrders, useRefunds, useReturns } from '@/hooks/use-api'

export function OrdersList() {
  return (
    <RecordsView
      label="orders"
      result={useOrders()}
      emptyIcon={Receipt}
      emptyTitle="No orders yet"
      emptyDescription="Orders placed at checkout will be listed here."
    />
  )
}

export function ReturnsList() {
  return (
    <RecordsView
      label="returns"
      result={useReturns()}
      emptyIcon={RotateCcw}
      emptyTitle="No returns"
      emptyDescription="Return requests from the returns table will appear here."
    />
  )
}

export function RefundsList() {
  return (
    <RecordsView
      label="refunds"
      result={useRefunds()}
      emptyIcon={Wallet}
      emptyTitle="No refunds"
      emptyDescription="Refunds issued against returns will appear here."
    />
  )
}
