'use client'

import { useState } from 'react'
import { Loader2, Plus, Trash2 } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { StockBadge } from '@/components/products/stock-badge'
import { ApiErrorState, EmptyState } from '@/components/shared/api-states'
import { useProducts } from '@/hooks/use-api'
import { API_BASE_URL, ApiError, createProduct, deleteProduct, ENDPOINTS } from '@/lib/api'
import { formatPrice } from '@/lib/format'
import { cn } from '@/lib/utils'

function describeError(error: unknown) {
  if (error instanceof ApiError && error.kind === 'not-implemented') {
    return `${error.endpoint} isn't available on the backend yet.`
  }
  return error instanceof Error ? error.message : 'Request failed.'
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-1 rounded-2xl border bg-card p-5">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="text-2xl font-semibold tabular-nums">{value}</p>
    </div>
  )
}

function AddProductForm({ onCreated }: { onCreated: () => void }) {
  const [form, setForm] = useState({ product_name: '', price: '', stock: '' })
  const [submitting, setSubmitting] = useState(false)
  const [formError, setFormError] = useState<string | null>(null)

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const name = form.product_name.trim()
    const price = Number(form.price)
    const stock = Number(form.stock)

    if (!name) return setFormError('Product name is required.')
    if (!Number.isFinite(price) || price < 0) return setFormError('Price must be a positive number.')
    if (!Number.isInteger(stock) || stock < 0) return setFormError('Stock must be a whole number.')

    setFormError(null)
    setSubmitting(true)
    try {
      await createProduct({ product_name: name, price, stock })
      toast.success('Product added', { description: name })
      setForm({ product_name: '', price: '', stock: '' })
      onCreated()
    } catch (error) {
      setFormError(describeError(error))
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4 rounded-2xl border bg-card p-6">
      <h2 className="font-medium">Add a product</h2>
      <div className="flex flex-col gap-2">
        <Label htmlFor="admin-name">Product name</Label>
        <Input
          id="admin-name"
          value={form.product_name}
          onChange={(e) => setForm((f) => ({ ...f, product_name: e.target.value }))}
          className="h-10"
        />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-2">
          <Label htmlFor="admin-price">Price (₹)</Label>
          <Input
            id="admin-price"
            type="number"
            inputMode="decimal"
            min="0"
            step="0.01"
            value={form.price}
            onChange={(e) => setForm((f) => ({ ...f, price: e.target.value }))}
            className="h-10"
          />
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="admin-stock">Stock</Label>
          <Input
            id="admin-stock"
            type="number"
            inputMode="numeric"
            min="0"
            step="1"
            value={form.stock}
            onChange={(e) => setForm((f) => ({ ...f, stock: e.target.value }))}
            className="h-10"
          />
        </div>
      </div>
      {formError && (
        <p role="alert" className="text-sm text-destructive">
          {formError}
        </p>
      )}
      <Button type="submit" disabled={submitting} className="h-10 rounded-full">
        {submitting ? <Loader2 data-icon="inline-start" className="animate-spin" /> : <Plus data-icon="inline-start" />}
        Add product
      </Button>
    </form>
  )
}

function EndpointStatus() {
  return (
    <div className="flex flex-col gap-4 rounded-2xl border bg-card p-6">
      <div className="flex flex-col gap-1">
        <h2 className="font-medium">Backend endpoints</h2>
        <p className="text-sm text-muted-foreground">
          Connected to <code className="font-mono text-xs text-foreground">{API_BASE_URL}</code>
        </p>
      </div>
      <ul className="flex flex-col gap-2 text-sm">
        {Object.values(ENDPOINTS).map((endpoint) => (
          <li key={`${endpoint.method} ${endpoint.path}`} className="flex items-center justify-between gap-3">
            <code className="font-mono text-xs">
              <span className="text-muted-foreground">{endpoint.method}</span> {endpoint.path}
            </code>
            <span
              className={cn(
                'rounded-full px-2 py-0.5 text-xs font-medium',
                endpoint.implemented ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning',
              )}
            >
              {endpoint.implemented ? 'Live' : 'Needed'}
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}

export function AdminDashboard() {
  const { data, error, isLoading, mutate } = useProducts()
  const [pendingDelete, setPendingDelete] = useState<number | null>(null)
  const [deleting, setDeleting] = useState<number | null>(null)

  const handleDelete = async (productId: number, name: string) => {
    if (pendingDelete !== productId) return setPendingDelete(productId)
    setDeleting(productId)
    try {
      await deleteProduct(productId)
      toast.success('Product deleted', { description: name })
      await mutate()
    } catch (err) {
      toast.error('Could not delete product', { description: describeError(err) })
    } finally {
      setDeleting(null)
      setPendingDelete(null)
    }
  }

  const products = data ?? []
  const inventoryValue = products.reduce((sum, p) => sum + p.price * p.stock, 0)
  const lowStock = products.filter((p) => p.stock > 0 && p.stock <= 10).length
  const outOfStock = products.filter((p) => p.stock <= 0).length

  return (
    <div className="flex flex-col gap-8">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Products" value={data ? String(products.length) : '—'} />
        <StatCard label="Inventory value" value={data ? formatPrice(inventoryValue) : '—'} />
        <StatCard label="Low stock" value={data ? String(lowStock) : '—'} />
        <StatCard label="Out of stock" value={data ? String(outOfStock) : '—'} />
      </div>

      <div className="grid items-start gap-8 lg:grid-cols-[1fr_340px]">
        <section aria-label="Products" className="min-w-0">
          {isLoading ? (
            <div role="status" aria-label="Loading products" className="flex flex-col gap-2 rounded-2xl border bg-card p-4">
              {Array.from({ length: 6 }, (_, i) => (
                <div key={i} className="h-10 animate-pulse rounded-lg bg-secondary" />
              ))}
            </div>
          ) : error ? (
            <ApiErrorState error={error} onRetry={() => mutate()} />
          ) : products.length === 0 ? (
            <EmptyState title="No products" description="Add your first product using the form." />
          ) : (
            <div className="overflow-hidden rounded-2xl border bg-card">
              <Table>
                <TableHeader>
                  <TableRow className="bg-secondary/50 hover:bg-secondary/50">
                    <TableHead className="h-11 px-4">ID</TableHead>
                    <TableHead className="h-11 px-4">Product</TableHead>
                    <TableHead className="h-11 px-4 text-right">Price</TableHead>
                    <TableHead className="h-11 px-4 text-right">Stock</TableHead>
                    <TableHead className="h-11 px-4">
                      <span className="sr-only">Actions</span>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {products.map((product) => (
                    <TableRow key={product.product_id}>
                      <TableCell className="px-4 font-mono text-xs text-muted-foreground">
                        #{product.product_id}
                      </TableCell>
                      <TableCell className="px-4">
                        <div className="flex flex-col gap-0.5">
                          <span className="font-medium">{product.product_name}</span>
                          <StockBadge stock={product.stock} />
                        </div>
                      </TableCell>
                      <TableCell className="px-4 text-right tabular-nums">{formatPrice(product.price)}</TableCell>
                      <TableCell className="px-4 text-right tabular-nums">{product.stock}</TableCell>
                      <TableCell className="px-4 text-right">
                        <Button
                          variant={pendingDelete === product.product_id ? 'destructive' : 'ghost'}
                          size="sm"
                          disabled={deleting === product.product_id}
                          onBlur={() => pendingDelete === product.product_id && setPendingDelete(null)}
                          onClick={() => handleDelete(product.product_id, product.product_name)}
                          aria-label={
                            pendingDelete === product.product_id
                              ? `Confirm delete ${product.product_name}`
                              : `Delete ${product.product_name}`
                          }
                        >
                          {deleting === product.product_id ? (
                            <Loader2 className="animate-spin" />
                          ) : (
                            <Trash2 />
                          )}
                          {pendingDelete === product.product_id && 'Confirm'}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </section>

        <div className="flex flex-col gap-6 lg:sticky lg:top-32">
          <AddProductForm onCreated={() => mutate()} />
          <EndpointStatus />
        </div>
      </div>
    </div>
  )
}
