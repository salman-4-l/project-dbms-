'use client'

import Link from 'next/link'
import { useState } from 'react'
import { CircleCheck, Loader2, ShoppingBag } from 'lucide-react'
import { Button, buttonVariants } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { OrderSummary } from '@/components/cart/order-summary'
import { ApiErrorState, StatePanel } from '@/components/shared/api-states'
import { createOrder } from '@/lib/api'
import { useCart } from '@/lib/cart-context'
import { formatPrice } from '@/lib/format'
import type { CheckoutCustomer } from '@/lib/types'
import { cn } from '@/lib/utils'

const emptyCustomer: CheckoutCustomer = { name: '', email: '', phone: '', address: '' }

type Status = { type: 'idle' } | { type: 'submitting' } | { type: 'error'; error: unknown } | { type: 'success' }

function validate(customer: CheckoutCustomer) {
  const errors: Partial<Record<keyof CheckoutCustomer, string>> = {}
  if (customer.name.trim().length < 2) errors.name = 'Enter your full name.'
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email.trim())) errors.email = 'Enter a valid email address.'
  if (!/^[+\d][\d\s-]{6,}$/.test(customer.phone.trim())) errors.phone = 'Enter a valid phone number.'
  if (customer.address.trim().length < 8) errors.address = 'Enter your full delivery address.'
  return errors
}

export function CheckoutView() {
  const { items, itemCount, subtotal, hydrated, clearCart } = useCart()
  const [customer, setCustomer] = useState(emptyCustomer)
  const [errors, setErrors] = useState<Partial<Record<keyof CheckoutCustomer, string>>>({})
  const [status, setStatus] = useState<Status>({ type: 'idle' })

  if (!hydrated) {
    return <div className="h-96 animate-pulse rounded-2xl bg-secondary" role="status" aria-label="Loading checkout" />
  }

  if (status.type === 'success') {
    return (
      <StatePanel
        icon={CircleCheck}
        title="Order placed"
        description="Thanks for your order. You can follow it from the orders page."
        action={
          <div className="flex gap-3">
            <Link href="/orders" className={cn(buttonVariants(), 'rounded-full')}>
              View orders
            </Link>
            <Link href="/products" className={cn(buttonVariants({ variant: 'outline' }), 'rounded-full')}>
              Keep shopping
            </Link>
          </div>
        }
      />
    )
  }

  if (items.length === 0) {
    return (
      <StatePanel
        icon={ShoppingBag}
        title="Nothing to check out"
        description="Add a few products to your cart first."
        action={
          <Link href="/products" className={cn(buttonVariants(), 'rounded-full')}>
            Browse products
          </Link>
        }
      />
    )
  }

  const update = (field: keyof CheckoutCustomer) => (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    setCustomer((current) => ({ ...current, [field]: event.target.value }))
    if (errors[field]) setErrors((current) => ({ ...current, [field]: undefined }))
  }

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const nextErrors = validate(customer)
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length > 0) return

    setStatus({ type: 'submitting' })
    try {
      await createOrder({
        customer: {
          name: customer.name.trim(),
          email: customer.email.trim(),
          phone: customer.phone.trim(),
          address: customer.address.trim(),
        },
        items: items.map(({ product, quantity }) => ({
          product_id: product.product_id,
          quantity,
          unit_price: product.price,
        })),
        total_amount: subtotal,
      })
      clearCart()
      setStatus({ type: 'success' })
    } catch (error) {
      setStatus({ type: 'error', error })
    }
  }

  const fields: { key: keyof CheckoutCustomer; label: string; type: string; autoComplete: string }[] = [
    { key: 'name', label: 'Full name', type: 'text', autoComplete: 'name' },
    { key: 'email', label: 'Email', type: 'email', autoComplete: 'email' },
    { key: 'phone', label: 'Phone', type: 'tel', autoComplete: 'tel' },
  ]

  return (
    <form onSubmit={handleSubmit} noValidate className="grid items-start gap-8 lg:grid-cols-[1fr_380px]">
      <div className="flex flex-col gap-6">
        <fieldset className="flex flex-col gap-5 rounded-2xl border bg-card p-6">
          <legend className="sr-only">Contact and delivery details</legend>
          <h2 className="font-medium">Contact &amp; delivery</h2>
          <div className="grid gap-5 sm:grid-cols-2">
            {fields.map((field) => (
              <div key={field.key} className={cn('flex flex-col gap-2', field.key === 'name' && 'sm:col-span-2')}>
                <Label htmlFor={`checkout-${field.key}`}>{field.label}</Label>
                <Input
                  id={`checkout-${field.key}`}
                  type={field.type}
                  autoComplete={field.autoComplete}
                  value={customer[field.key]}
                  onChange={update(field.key)}
                  aria-invalid={Boolean(errors[field.key])}
                  aria-describedby={errors[field.key] ? `checkout-${field.key}-error` : undefined}
                  className="h-10"
                />
                {errors[field.key] && (
                  <p id={`checkout-${field.key}-error`} className="text-sm text-destructive">
                    {errors[field.key]}
                  </p>
                )}
              </div>
            ))}
            <div className="flex flex-col gap-2 sm:col-span-2">
              <Label htmlFor="checkout-address">Delivery address</Label>
              <Textarea
                id="checkout-address"
                autoComplete="street-address"
                rows={3}
                value={customer.address}
                onChange={update('address')}
                aria-invalid={Boolean(errors.address)}
                aria-describedby={errors.address ? 'checkout-address-error' : undefined}
              />
              {errors.address && (
                <p id="checkout-address-error" className="text-sm text-destructive">
                  {errors.address}
                </p>
              )}
            </div>
          </div>
        </fieldset>

        {status.type === 'error' && <ApiErrorState error={status.error} className="py-10" />}
      </div>

      <div className="lg:sticky lg:top-32">
        <OrderSummary subtotal={subtotal} itemCount={itemCount}>
          <ul className="flex flex-col gap-2 border-t pt-4 text-sm">
            {items.map(({ product, quantity }) => (
              <li key={product.product_id} className="flex justify-between gap-3">
                <span className="text-muted-foreground">
                  {product.product_name} <span className="tabular-nums">× {quantity}</span>
                </span>
                <span className="tabular-nums">{formatPrice(product.price * quantity)}</span>
              </li>
            ))}
          </ul>
          <Button type="submit" size="lg" className="h-11 rounded-full" disabled={status.type === 'submitting'}>
            {status.type === 'submitting' && <Loader2 data-icon="inline-start" className="animate-spin" />}
            {status.type === 'submitting' ? 'Placing order…' : `Place order · ${formatPrice(subtotal)}`}
          </Button>
        </OrderSummary>
      </div>
    </form>
  )
}
