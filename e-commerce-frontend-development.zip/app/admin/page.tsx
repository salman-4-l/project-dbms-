import type { Metadata } from 'next'
import { AdminDashboard } from '@/components/admin/admin-dashboard'
import { PageHeader } from '@/components/shared/page-header'

export const metadata: Metadata = { title: 'Admin', robots: { index: false } }

export default function AdminPage() {
  return (
    <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="Admin"
        title="Inventory"
        description="Manage the products table and check which backend endpoints are available."
      />
      <AdminDashboard />
    </main>
  )
}
