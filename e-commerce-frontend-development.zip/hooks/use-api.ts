'use client'

import useSWR from 'swr'
import { getOrders, getProducts, getRefunds, getReturns, type ApiError } from '@/lib/api'
import type { ApiRecord, Product } from '@/lib/types'

const options = { revalidateOnFocus: false, shouldRetryOnError: false }

export function useProducts() {
  return useSWR<Product[], ApiError>('products', getProducts, options)
}

export function useOrders() {
  return useSWR<ApiRecord[], ApiError>('orders', getOrders, options)
}

export function useReturns() {
  return useSWR<ApiRecord[], ApiError>('returns', getReturns, options)
}

export function useRefunds() {
  return useSWR<ApiRecord[], ApiError>('refunds', getRefunds, options)
}
